import React from 'react'
import './pakkeløsninger.css'
import Tilvalg from './Tilvalg'


const PakkeLøsnigner = () => {

  
  return (
    <section id="pakkeløsninger">
        <h2>Pakkeløsnigner</h2>
        <p>Vi tilbyder forskellige løsninger til netop din virksomhed</p>
             <Tilvalg />
        <div className='cards-container'>
        
        </div>

    </section>
  )
}

export default PakkeLøsnigner
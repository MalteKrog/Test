import React from 'react'

const BaeredygtighedPage = () => {
  return (
    <div>BaeredygtighedPage</div>
  )
}

export default BaeredygtighedPage